package io.github.sunflower;

import java.util.*;
public class Main {
    public static void main(String args[]) {
        Scanner inp = new Scanner(System.in);
        System.out.println("输入歌曲网页链接id");
        System.out.println("  如https://music.163.com/#/song?id=551339740 id为551339740");
        String inurl = inp.nextLine();
        String oturl = "rundll32 url.dll,FileProtocolHandler https://music.163.com/song/media/outer/url?id=" + inurl + ".mp3";
        try {
            Process pc = Runtime.getRuntime().exec(oturl);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
